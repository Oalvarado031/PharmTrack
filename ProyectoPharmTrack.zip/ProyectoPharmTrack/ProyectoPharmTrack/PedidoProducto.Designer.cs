﻿namespace PedidoDeProductoFarmTrack
{
    partial class PedidoProducto
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombreCompleto = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblDireccionDeEntrega = new System.Windows.Forms.Label();
            this.lblCorreoElectronico = new System.Windows.Forms.Label();
            this.grpDatosDelCliente = new System.Windows.Forms.GroupBox();
            this.mtxtTelefono = new System.Windows.Forms.MaskedTextBox();
            this.txtNombreCompleto = new System.Windows.Forms.TextBox();
            this.txtCorreoElectronico = new System.Windows.Forms.TextBox();
            this.txtDireccionDeEntrega = new System.Windows.Forms.TextBox();
            this.grpDetallesDelProducto = new System.Windows.Forms.GroupBox();
            this.dtpFechaDePedido = new System.Windows.Forms.DateTimePicker();
            this.cmbPresentacion = new System.Windows.Forms.ComboBox();
            this.txtProducto = new System.Windows.Forms.TextBox();
            this.nudCantidad = new System.Windows.Forms.NumericUpDown();
            this.lblFechaDePedido = new System.Windows.Forms.Label();
            this.lblPresentacion = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.lblProducto = new System.Windows.Forms.Label();
            this.grpMetodoDePago = new System.Windows.Forms.GroupBox();
            this.radTarjeta = new System.Windows.Forms.RadioButton();
            this.radTransferencia = new System.Windows.Forms.RadioButton();
            this.radEfectivo = new System.Windows.Forms.RadioButton();
            this.lblDatosDePago = new System.Windows.Forms.Label();
            this.lblOpcionesDePago = new System.Windows.Forms.Label();
            this.btnAgregarPedido = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblPedidosRegistrados = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.volverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnBorrarCampos = new System.Windows.Forms.Button();
            this.grpDatosDelCliente.SuspendLayout();
            this.grpDetallesDelProducto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCantidad)).BeginInit();
            this.grpMetodoDePago.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNombreCompleto
            // 
            this.lblNombreCompleto.AutoSize = true;
            this.lblNombreCompleto.Location = new System.Drawing.Point(6, 35);
            this.lblNombreCompleto.Name = "lblNombreCompleto";
            this.lblNombreCompleto.Size = new System.Drawing.Size(159, 22);
            this.lblNombreCompleto.TabIndex = 0;
            this.lblNombreCompleto.Text = "Nombre Completo:";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(6, 75);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(86, 22);
            this.lblTelefono.TabIndex = 1;
            this.lblTelefono.Text = "Teléfono:";
            // 
            // lblDireccionDeEntrega
            // 
            this.lblDireccionDeEntrega.AutoSize = true;
            this.lblDireccionDeEntrega.Location = new System.Drawing.Point(6, 117);
            this.lblDireccionDeEntrega.Name = "lblDireccionDeEntrega";
            this.lblDireccionDeEntrega.Size = new System.Drawing.Size(183, 22);
            this.lblDireccionDeEntrega.TabIndex = 2;
            this.lblDireccionDeEntrega.Text = "Dirección de Entrega:";
            // 
            // lblCorreoElectronico
            // 
            this.lblCorreoElectronico.AutoSize = true;
            this.lblCorreoElectronico.Location = new System.Drawing.Point(6, 226);
            this.lblCorreoElectronico.Name = "lblCorreoElectronico";
            this.lblCorreoElectronico.Size = new System.Drawing.Size(164, 22);
            this.lblCorreoElectronico.TabIndex = 3;
            this.lblCorreoElectronico.Text = "Correo Eléctronico:";
            // 
            // grpDatosDelCliente
            // 
            this.grpDatosDelCliente.Controls.Add(this.mtxtTelefono);
            this.grpDatosDelCliente.Controls.Add(this.txtNombreCompleto);
            this.grpDatosDelCliente.Controls.Add(this.txtCorreoElectronico);
            this.grpDatosDelCliente.Controls.Add(this.txtDireccionDeEntrega);
            this.grpDatosDelCliente.Controls.Add(this.lblNombreCompleto);
            this.grpDatosDelCliente.Controls.Add(this.lblCorreoElectronico);
            this.grpDatosDelCliente.Controls.Add(this.lblTelefono);
            this.grpDatosDelCliente.Controls.Add(this.lblDireccionDeEntrega);
            this.grpDatosDelCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDatosDelCliente.ForeColor = System.Drawing.SystemColors.MenuText;
            this.grpDatosDelCliente.Location = new System.Drawing.Point(12, 34);
            this.grpDatosDelCliente.Name = "grpDatosDelCliente";
            this.grpDatosDelCliente.Size = new System.Drawing.Size(592, 270);
            this.grpDatosDelCliente.TabIndex = 4;
            this.grpDatosDelCliente.TabStop = false;
            this.grpDatosDelCliente.Text = "Datos del Cliente";
            // 
            // mtxtTelefono
            // 
            this.mtxtTelefono.Location = new System.Drawing.Point(195, 72);
            this.mtxtTelefono.Mask = "+(000) 0000-0000";
            this.mtxtTelefono.Name = "mtxtTelefono";
            this.mtxtTelefono.Size = new System.Drawing.Size(391, 28);
            this.mtxtTelefono.TabIndex = 7;
            this.mtxtTelefono.Click += new System.EventHandler(this.PosicionDeInicio_Click);
            this.mtxtTelefono.Enter += new System.EventHandler(this.PosicionDeInicio_Enter);
            // 
            // txtNombreCompleto
            // 
            this.txtNombreCompleto.Location = new System.Drawing.Point(195, 32);
            this.txtNombreCompleto.Name = "txtNombreCompleto";
            this.txtNombreCompleto.Size = new System.Drawing.Size(391, 28);
            this.txtNombreCompleto.TabIndex = 6;
            this.txtNombreCompleto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ValidacionSoloLetras);
            // 
            // txtCorreoElectronico
            // 
            this.txtCorreoElectronico.Location = new System.Drawing.Point(195, 223);
            this.txtCorreoElectronico.Name = "txtCorreoElectronico";
            this.txtCorreoElectronico.Size = new System.Drawing.Size(391, 28);
            this.txtCorreoElectronico.TabIndex = 5;
            // 
            // txtDireccionDeEntrega
            // 
            this.txtDireccionDeEntrega.Location = new System.Drawing.Point(195, 114);
            this.txtDireccionDeEntrega.Multiline = true;
            this.txtDireccionDeEntrega.Name = "txtDireccionDeEntrega";
            this.txtDireccionDeEntrega.Size = new System.Drawing.Size(391, 103);
            this.txtDireccionDeEntrega.TabIndex = 4;
            // 
            // grpDetallesDelProducto
            // 
            this.grpDetallesDelProducto.Controls.Add(this.dtpFechaDePedido);
            this.grpDetallesDelProducto.Controls.Add(this.cmbPresentacion);
            this.grpDetallesDelProducto.Controls.Add(this.txtProducto);
            this.grpDetallesDelProducto.Controls.Add(this.nudCantidad);
            this.grpDetallesDelProducto.Controls.Add(this.lblFechaDePedido);
            this.grpDetallesDelProducto.Controls.Add(this.lblPresentacion);
            this.grpDetallesDelProducto.Controls.Add(this.lblCantidad);
            this.grpDetallesDelProducto.Controls.Add(this.lblProducto);
            this.grpDetallesDelProducto.Location = new System.Drawing.Point(610, 34);
            this.grpDetallesDelProducto.Name = "grpDetallesDelProducto";
            this.grpDetallesDelProducto.Size = new System.Drawing.Size(531, 270);
            this.grpDetallesDelProducto.TabIndex = 5;
            this.grpDetallesDelProducto.TabStop = false;
            this.grpDetallesDelProducto.Text = "Detalles del Producto";
            // 
            // dtpFechaDePedido
            // 
            this.dtpFechaDePedido.Location = new System.Drawing.Point(210, 167);
            this.dtpFechaDePedido.Name = "dtpFechaDePedido";
            this.dtpFechaDePedido.Size = new System.Drawing.Size(288, 28);
            this.dtpFechaDePedido.TabIndex = 8;
            // 
            // cmbPresentacion
            // 
            this.cmbPresentacion.FormattingEnabled = true;
            this.cmbPresentacion.Items.AddRange(new object[] {
            "Tabletas",
            "Jarabe",
            "Ampolla"});
            this.cmbPresentacion.Location = new System.Drawing.Point(210, 117);
            this.cmbPresentacion.Name = "cmbPresentacion";
            this.cmbPresentacion.Size = new System.Drawing.Size(288, 30);
            this.cmbPresentacion.TabIndex = 7;
            // 
            // txtProducto
            // 
            this.txtProducto.Location = new System.Drawing.Point(210, 32);
            this.txtProducto.Name = "txtProducto";
            this.txtProducto.Size = new System.Drawing.Size(288, 28);
            this.txtProducto.TabIndex = 6;
            // 
            // nudCantidad
            // 
            this.nudCantidad.Location = new System.Drawing.Point(210, 72);
            this.nudCantidad.Name = "nudCantidad";
            this.nudCantidad.Size = new System.Drawing.Size(120, 28);
            this.nudCantidad.TabIndex = 5;
            // 
            // lblFechaDePedido
            // 
            this.lblFechaDePedido.AutoSize = true;
            this.lblFechaDePedido.Location = new System.Drawing.Point(6, 167);
            this.lblFechaDePedido.Name = "lblFechaDePedido";
            this.lblFechaDePedido.Size = new System.Drawing.Size(151, 22);
            this.lblFechaDePedido.TabIndex = 3;
            this.lblFechaDePedido.Text = "Fecha de Pedido:";
            // 
            // lblPresentacion
            // 
            this.lblPresentacion.AutoSize = true;
            this.lblPresentacion.Location = new System.Drawing.Point(6, 117);
            this.lblPresentacion.Name = "lblPresentacion";
            this.lblPresentacion.Size = new System.Drawing.Size(120, 22);
            this.lblPresentacion.TabIndex = 2;
            this.lblPresentacion.Text = "Presentación:";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Location = new System.Drawing.Point(6, 75);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(87, 22);
            this.lblCantidad.TabIndex = 1;
            this.lblCantidad.Text = "Cantidad:";
            // 
            // lblProducto
            // 
            this.lblProducto.AutoSize = true;
            this.lblProducto.Location = new System.Drawing.Point(6, 35);
            this.lblProducto.Name = "lblProducto";
            this.lblProducto.Size = new System.Drawing.Size(198, 22);
            this.lblProducto.TabIndex = 0;
            this.lblProducto.Text = "Producto/Medicamento:";
            // 
            // grpMetodoDePago
            // 
            this.grpMetodoDePago.Controls.Add(this.radTarjeta);
            this.grpMetodoDePago.Controls.Add(this.radTransferencia);
            this.grpMetodoDePago.Controls.Add(this.radEfectivo);
            this.grpMetodoDePago.Controls.Add(this.lblDatosDePago);
            this.grpMetodoDePago.Controls.Add(this.lblOpcionesDePago);
            this.grpMetodoDePago.Location = new System.Drawing.Point(3, 310);
            this.grpMetodoDePago.Name = "grpMetodoDePago";
            this.grpMetodoDePago.Size = new System.Drawing.Size(700, 127);
            this.grpMetodoDePago.TabIndex = 6;
            this.grpMetodoDePago.TabStop = false;
            this.grpMetodoDePago.Text = "Método de Pago";
            // 
            // radTarjeta
            // 
            this.radTarjeta.AutoSize = true;
            this.radTarjeta.Location = new System.Drawing.Point(458, 39);
            this.radTarjeta.Name = "radTarjeta";
            this.radTarjeta.Size = new System.Drawing.Size(233, 26);
            this.radTarjeta.TabIndex = 4;
            this.radTarjeta.TabStop = true;
            this.radTarjeta.Text = "Tarjeta de Crédito/Débito";
            this.radTarjeta.UseVisualStyleBackColor = true;
            // 
            // radTransferencia
            // 
            this.radTransferencia.AutoSize = true;
            this.radTransferencia.Location = new System.Drawing.Point(305, 39);
            this.radTransferencia.Name = "radTransferencia";
            this.radTransferencia.Size = new System.Drawing.Size(147, 26);
            this.radTransferencia.TabIndex = 3;
            this.radTransferencia.TabStop = true;
            this.radTransferencia.Text = "Transferencia ";
            this.radTransferencia.UseVisualStyleBackColor = true;
            // 
            // radEfectivo
            // 
            this.radEfectivo.AutoSize = true;
            this.radEfectivo.Location = new System.Drawing.Point(204, 39);
            this.radEfectivo.Name = "radEfectivo";
            this.radEfectivo.Size = new System.Drawing.Size(95, 26);
            this.radEfectivo.TabIndex = 2;
            this.radEfectivo.TabStop = true;
            this.radEfectivo.Text = "Efectivo";
            this.radEfectivo.UseVisualStyleBackColor = true;
            // 
            // lblDatosDePago
            // 
            this.lblDatosDePago.AutoSize = true;
            this.lblDatosDePago.Location = new System.Drawing.Point(15, 78);
            this.lblDatosDePago.Name = "lblDatosDePago";
            this.lblDatosDePago.Size = new System.Drawing.Size(134, 22);
            this.lblDatosDePago.TabIndex = 1;
            this.lblDatosDePago.Text = "Datos de Pago:";
            // 
            // lblOpcionesDePago
            // 
            this.lblOpcionesDePago.AutoSize = true;
            this.lblOpcionesDePago.Location = new System.Drawing.Point(15, 39);
            this.lblOpcionesDePago.Name = "lblOpcionesDePago";
            this.lblOpcionesDePago.Size = new System.Drawing.Size(163, 22);
            this.lblOpcionesDePago.TabIndex = 0;
            this.lblOpcionesDePago.Text = "Opciones de Pago:";
            // 
            // btnAgregarPedido
            // 
            this.btnAgregarPedido.Location = new System.Drawing.Point(728, 321);
            this.btnAgregarPedido.Name = "btnAgregarPedido";
            this.btnAgregarPedido.Size = new System.Drawing.Size(170, 39);
            this.btnAgregarPedido.TabIndex = 7;
            this.btnAgregarPedido.Text = "Agregar Pedido";
            this.btnAgregarPedido.UseVisualStyleBackColor = true;
            this.btnAgregarPedido.Click += new System.EventHandler(this.btnAgregarPedido_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(728, 388);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(413, 263);
            this.dataGridView1.TabIndex = 9;
            // 
            // lblPedidosRegistrados
            // 
            this.lblPedidosRegistrados.AutoSize = true;
            this.lblPedidosRegistrados.Location = new System.Drawing.Point(854, 363);
            this.lblPedidosRegistrados.Name = "lblPedidosRegistrados";
            this.lblPedidosRegistrados.Size = new System.Drawing.Size(176, 22);
            this.lblPedidosRegistrados.TabIndex = 10;
            this.lblPedidosRegistrados.Text = "Pedidos Registrados";
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(60, 40);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(102, 53);
            this.btnEliminar.TabIndex = 11;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnActualizar);
            this.groupBox1.Controls.Add(this.btnEliminar);
            this.groupBox1.Location = new System.Drawing.Point(500, 450);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(222, 201);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opciones de Registros";
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(60, 108);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(102, 53);
            this.btnActualizar.TabIndex = 12;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.volverToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1153, 28);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // volverToolStripMenuItem
            // 
            this.volverToolStripMenuItem.Name = "volverToolStripMenuItem";
            this.volverToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.volverToolStripMenuItem.Text = "Volver";
            this.volverToolStripMenuItem.Click += new System.EventHandler(this.volverToolStripMenuItem_Click);
            // 
            // btnBorrarCampos
            // 
            this.btnBorrarCampos.Location = new System.Drawing.Point(971, 321);
            this.btnBorrarCampos.Name = "btnBorrarCampos";
            this.btnBorrarCampos.Size = new System.Drawing.Size(170, 39);
            this.btnBorrarCampos.TabIndex = 15;
            this.btnBorrarCampos.Text = "Borrar Campos";
            this.btnBorrarCampos.UseVisualStyleBackColor = true;
            this.btnBorrarCampos.Click += new System.EventHandler(this.btnBorrarCampos_Click);
            // 
            // PedidoProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 663);
            this.Controls.Add(this.btnBorrarCampos);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblPedidosRegistrados);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnAgregarPedido);
            this.Controls.Add(this.grpMetodoDePago);
            this.Controls.Add(this.grpDetallesDelProducto);
            this.Controls.Add(this.grpDatosDelCliente);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PedidoProducto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pedido de Producto";
            this.grpDatosDelCliente.ResumeLayout(false);
            this.grpDatosDelCliente.PerformLayout();
            this.grpDetallesDelProducto.ResumeLayout(false);
            this.grpDetallesDelProducto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCantidad)).EndInit();
            this.grpMetodoDePago.ResumeLayout(false);
            this.grpMetodoDePago.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombreCompleto;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblDireccionDeEntrega;
        private System.Windows.Forms.Label lblCorreoElectronico;
        private System.Windows.Forms.GroupBox grpDatosDelCliente;
        private System.Windows.Forms.TextBox txtDireccionDeEntrega;
        private System.Windows.Forms.TextBox txtNombreCompleto;
        private System.Windows.Forms.TextBox txtCorreoElectronico;
        private System.Windows.Forms.GroupBox grpDetallesDelProducto;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.Label lblProducto;
        private System.Windows.Forms.Label lblFechaDePedido;
        private System.Windows.Forms.Label lblPresentacion;
        private System.Windows.Forms.NumericUpDown nudCantidad;
        private System.Windows.Forms.ComboBox cmbPresentacion;
        private System.Windows.Forms.TextBox txtProducto;
        private System.Windows.Forms.DateTimePicker dtpFechaDePedido;
        private System.Windows.Forms.GroupBox grpMetodoDePago;
        private System.Windows.Forms.Label lblDatosDePago;
        private System.Windows.Forms.Label lblOpcionesDePago;
        private System.Windows.Forms.RadioButton radTransferencia;
        private System.Windows.Forms.RadioButton radEfectivo;
        private System.Windows.Forms.RadioButton radTarjeta;
        private System.Windows.Forms.Button btnAgregarPedido;
        private System.Windows.Forms.MaskedTextBox mtxtTelefono;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblPedidosRegistrados;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem volverToolStripMenuItem;
        private System.Windows.Forms.Button btnBorrarCampos;
    }
}

