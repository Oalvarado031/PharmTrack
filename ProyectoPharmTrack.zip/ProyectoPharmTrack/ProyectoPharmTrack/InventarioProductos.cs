﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfazLoginPharmaTrack
{
        public struct InventarioProductos
        {
        public int CodigoMedicamento { get; set; }
        public string NombreMedicamento { get; set; }
        public string DescripcionMedicamento { get; set; }
        public string TipoMedicamento { get; set; }
        public int StockMedicamento { get; set; }
        public string UnidadMedida { get; set; }
        public int CantidadEmpaque { get; set; }
        public DateTime FechaDeEntrada { get; set; }

        public DateTime FechaDeSalida { get; set; }

        public float PrecioDeCompra {  get; set; }

        public float PrecioDeVenta { get; set; }

        public string DescuentoAplicable { get; set; }

        public string NombreProveedor { get; set; }

        public int CodigoProveedor { get; set; }

        public int ContactoProveedor { get; set; }


    }
    
}
