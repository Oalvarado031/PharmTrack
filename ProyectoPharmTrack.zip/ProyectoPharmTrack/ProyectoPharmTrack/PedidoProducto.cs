﻿using InterfazLoginPharmaTrack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PedidoDeProductoFarmTrack
{
    public partial class PedidoProducto : Form
    {
        public PedidoProducto()
        {
            InitializeComponent();
        }

        private void ValidacionSoloLetras(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void PosicionDeInicio_Click(object sender, EventArgs e)
        {
            //Mueve el cursor al inicio del MaskedTextBox
            (sender as MaskedTextBox).SelectionStart = 0;
        }

        private void PosicionDeInicio_Enter(object sender, EventArgs e)
        {
            /*Igual mueve el cursor al inicio, pero cuando recibe el foco a través de otros medios,
            por ejemplo al presionat TAB*/
            (sender as MaskedTextBox).SelectionStart = 0;
        }


        private void volverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Opciones opcc = new Opciones();
            opcc.Show();
            this.Close();
        }

        private void btnAgregarPedido_Click(object sender, EventArgs e)
        {
            //Datos del Cliente
            string nombreCompleto = txtNombreCompleto.Text;
            string telefono = mtxtTelefono.Text;
            string direccionDeEntrega = txtDireccionDeEntrega.Text;
            string correoElectronico = txtCorreoElectronico.Text;

            //Detalles del Producto
            string productoMedicamento = txtProducto.Text;
            decimal cantidad = nudCantidad.Value;
            string presentacion = cmbPresentacion.Text;
            string fechaDePedido = dtpFechaDePedido.Text;

            bool efectivo = radEfectivo.Checked;
            bool tarjeta = radTarjeta.Checked;
            bool transferencia = radTransferencia.Checked;

            if (nombreCompleto == "" || telefono == "" || direccionDeEntrega == "" || correoElectronico == ""
                || productoMedicamento == "" || cantidad == 0 || presentacion == "" || efectivo == false && tarjeta == false && transferencia == false)
            {
                MessageBox.Show("Debe Completar Todos los Campos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Pedido Realizado Exitosamente", "Pharm Track", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnBorrarCampos_Click(object sender, EventArgs e)
        {
            txtNombreCompleto.Clear();
            
        }
    }
}
