﻿namespace ProyectoPharmTrack
{
    partial class PharmTrack
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PharmTrack));
            this.label1 = new System.Windows.Forms.Label();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblTipo = new System.Windows.Forms.Label();
            this.grpInformacionMedicamento = new System.Windows.Forms.GroupBox();
            this.txtTipoMedicamento = new System.Windows.Forms.TextBox();
            this.txtDescripcionMedicamento = new System.Windows.Forms.TextBox();
            this.txtNombreMedicamento = new System.Windows.Forms.TextBox();
            this.txtCodigoMedicamento = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpCantidadPresentacion = new System.Windows.Forms.GroupBox();
            this.txtCantidadEmpaque = new System.Windows.Forms.TextBox();
            this.txtUnidadMedida = new System.Windows.Forms.TextBox();
            this.txtCantidadStock = new System.Windows.Forms.TextBox();
            this.lblCantidadEmpaque = new System.Windows.Forms.Label();
            this.lblStock = new System.Windows.Forms.Label();
            this.lblMedida = new System.Windows.Forms.Label();
            this.grpInformacionPrecioVenta = new System.Windows.Forms.GroupBox();
            this.radNo = new System.Windows.Forms.RadioButton();
            this.txtPrecioVenta = new System.Windows.Forms.TextBox();
            this.radSi = new System.Windows.Forms.RadioButton();
            this.txtPrecioCompra = new System.Windows.Forms.TextBox();
            this.lblDescuento = new System.Windows.Forms.Label();
            this.lblPrecioCompra = new System.Windows.Forms.Label();
            this.lblPrecioVenta = new System.Windows.Forms.Label();
            this.grpInformacionProveedor = new System.Windows.Forms.GroupBox();
            this.mtxtContacto = new System.Windows.Forms.MaskedTextBox();
            this.txtCodigoProveedor = new System.Windows.Forms.TextBox();
            this.txtNombreProveedor = new System.Windows.Forms.TextBox();
            this.lblContactoProveedor = new System.Windows.Forms.Label();
            this.lblNombreProveedor = new System.Windows.Forms.Label();
            this.lblCodigoProveedor = new System.Windows.Forms.Label();
            this.grpFechasImportantes = new System.Windows.Forms.GroupBox();
            this.mtxtFechaCaducidad = new System.Windows.Forms.MaskedTextBox();
            this.mtxtFechaEntrada = new System.Windows.Forms.MaskedTextBox();
            this.lblFechaEntrada = new System.Windows.Forms.Label();
            this.lblFechaCaducidad = new System.Windows.Forms.Label();
            this.grpInformacionMedicamento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpCantidadPresentacion.SuspendLayout();
            this.grpInformacionPrecioVenta.SuspendLayout();
            this.grpInformacionProveedor.SuspendLayout();
            this.grpFechasImportantes.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(328, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "PharmTrack";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Location = new System.Drawing.Point(32, 21);
            this.lblCodigo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(43, 13);
            this.lblCodigo.TabIndex = 1;
            this.lblCodigo.Text = "Código:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(32, 52);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(47, 13);
            this.lblNombre.TabIndex = 2;
            this.lblNombre.Text = "Nombre:";
            this.lblNombre.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(32, 82);
            this.lblDescripcion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(66, 13);
            this.lblDescripcion.TabIndex = 3;
            this.lblDescripcion.Text = "Descripción:";
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(32, 126);
            this.lblTipo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(31, 13);
            this.lblTipo.TabIndex = 4;
            this.lblTipo.Text = "Tipo:";
            // 
            // grpInformacionMedicamento
            // 
            this.grpInformacionMedicamento.Controls.Add(this.txtTipoMedicamento);
            this.grpInformacionMedicamento.Controls.Add(this.txtDescripcionMedicamento);
            this.grpInformacionMedicamento.Controls.Add(this.txtNombreMedicamento);
            this.grpInformacionMedicamento.Controls.Add(this.txtCodigoMedicamento);
            this.grpInformacionMedicamento.Controls.Add(this.lblDescripcion);
            this.grpInformacionMedicamento.Controls.Add(this.lblTipo);
            this.grpInformacionMedicamento.Controls.Add(this.lblCodigo);
            this.grpInformacionMedicamento.Controls.Add(this.lblNombre);
            this.grpInformacionMedicamento.Location = new System.Drawing.Point(9, 57);
            this.grpInformacionMedicamento.Margin = new System.Windows.Forms.Padding(2);
            this.grpInformacionMedicamento.Name = "grpInformacionMedicamento";
            this.grpInformacionMedicamento.Padding = new System.Windows.Forms.Padding(2);
            this.grpInformacionMedicamento.Size = new System.Drawing.Size(299, 150);
            this.grpInformacionMedicamento.TabIndex = 5;
            this.grpInformacionMedicamento.TabStop = false;
            this.grpInformacionMedicamento.Text = "Información del Medicamento";
            this.grpInformacionMedicamento.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtTipoMedicamento
            // 
            this.txtTipoMedicamento.Location = new System.Drawing.Point(82, 123);
            this.txtTipoMedicamento.Name = "txtTipoMedicamento";
            this.txtTipoMedicamento.Size = new System.Drawing.Size(100, 20);
            this.txtTipoMedicamento.TabIndex = 7;
            // 
            // txtDescripcionMedicamento
            // 
            this.txtDescripcionMedicamento.Location = new System.Drawing.Point(100, 79);
            this.txtDescripcionMedicamento.Multiline = true;
            this.txtDescripcionMedicamento.Name = "txtDescripcionMedicamento";
            this.txtDescripcionMedicamento.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescripcionMedicamento.Size = new System.Drawing.Size(181, 31);
            this.txtDescripcionMedicamento.TabIndex = 6;
            // 
            // txtNombreMedicamento
            // 
            this.txtNombreMedicamento.Location = new System.Drawing.Point(82, 49);
            this.txtNombreMedicamento.Name = "txtNombreMedicamento";
            this.txtNombreMedicamento.Size = new System.Drawing.Size(141, 20);
            this.txtNombreMedicamento.TabIndex = 5;
            // 
            // txtCodigoMedicamento
            // 
            this.txtCodigoMedicamento.Location = new System.Drawing.Point(82, 18);
            this.txtCodigoMedicamento.Margin = new System.Windows.Forms.Padding(2);
            this.txtCodigoMedicamento.Name = "txtCodigoMedicamento";
            this.txtCodigoMedicamento.Size = new System.Drawing.Size(75, 20);
            this.txtCodigoMedicamento.TabIndex = 4;
            this.txtCodigoMedicamento.TextChanged += new System.EventHandler(this.txtCodigo_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(322, 139);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(164, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // grpCantidadPresentacion
            // 
            this.grpCantidadPresentacion.Controls.Add(this.txtCantidadEmpaque);
            this.grpCantidadPresentacion.Controls.Add(this.txtUnidadMedida);
            this.grpCantidadPresentacion.Controls.Add(this.txtCantidadStock);
            this.grpCantidadPresentacion.Controls.Add(this.lblCantidadEmpaque);
            this.grpCantidadPresentacion.Controls.Add(this.lblStock);
            this.grpCantidadPresentacion.Controls.Add(this.lblMedida);
            this.grpCantidadPresentacion.Location = new System.Drawing.Point(9, 223);
            this.grpCantidadPresentacion.Margin = new System.Windows.Forms.Padding(2);
            this.grpCantidadPresentacion.Name = "grpCantidadPresentacion";
            this.grpCantidadPresentacion.Padding = new System.Windows.Forms.Padding(2);
            this.grpCantidadPresentacion.Size = new System.Drawing.Size(299, 150);
            this.grpCantidadPresentacion.TabIndex = 7;
            this.grpCantidadPresentacion.TabStop = false;
            this.grpCantidadPresentacion.Text = "Datos de Cantidad y Presentación";
            // 
            // txtCantidadEmpaque
            // 
            this.txtCantidadEmpaque.Location = new System.Drawing.Point(166, 97);
            this.txtCantidadEmpaque.Name = "txtCantidadEmpaque";
            this.txtCantidadEmpaque.Size = new System.Drawing.Size(64, 20);
            this.txtCantidadEmpaque.TabIndex = 6;
            // 
            // txtUnidadMedida
            // 
            this.txtUnidadMedida.Location = new System.Drawing.Point(147, 62);
            this.txtUnidadMedida.Name = "txtUnidadMedida";
            this.txtUnidadMedida.Size = new System.Drawing.Size(64, 20);
            this.txtUnidadMedida.TabIndex = 5;
            // 
            // txtCantidadStock
            // 
            this.txtCantidadStock.Location = new System.Drawing.Point(147, 28);
            this.txtCantidadStock.Name = "txtCantidadStock";
            this.txtCantidadStock.Size = new System.Drawing.Size(64, 20);
            this.txtCantidadStock.TabIndex = 4;
            // 
            // lblCantidadEmpaque
            // 
            this.lblCantidadEmpaque.AutoSize = true;
            this.lblCantidadEmpaque.Location = new System.Drawing.Point(32, 100);
            this.lblCantidadEmpaque.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCantidadEmpaque.Name = "lblCantidadEmpaque";
            this.lblCantidadEmpaque.Size = new System.Drawing.Size(118, 13);
            this.lblCantidadEmpaque.TabIndex = 3;
            this.lblCantidadEmpaque.Text = "Cantidad por Empaque:";
            this.lblCantidadEmpaque.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblStock
            // 
            this.lblStock.AutoSize = true;
            this.lblStock.Location = new System.Drawing.Point(32, 32);
            this.lblStock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(98, 13);
            this.lblStock.TabIndex = 1;
            this.lblStock.Text = "Cantidad en Stock:";
            // 
            // lblMedida
            // 
            this.lblMedida.AutoSize = true;
            this.lblMedida.Location = new System.Drawing.Point(32, 65);
            this.lblMedida.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMedida.Name = "lblMedida";
            this.lblMedida.Size = new System.Drawing.Size(97, 13);
            this.lblMedida.TabIndex = 2;
            this.lblMedida.Text = "Unidad de Medida:";
            // 
            // grpInformacionPrecioVenta
            // 
            this.grpInformacionPrecioVenta.Controls.Add(this.radNo);
            this.grpInformacionPrecioVenta.Controls.Add(this.txtPrecioVenta);
            this.grpInformacionPrecioVenta.Controls.Add(this.radSi);
            this.grpInformacionPrecioVenta.Controls.Add(this.txtPrecioCompra);
            this.grpInformacionPrecioVenta.Controls.Add(this.lblDescuento);
            this.grpInformacionPrecioVenta.Controls.Add(this.lblPrecioCompra);
            this.grpInformacionPrecioVenta.Controls.Add(this.lblPrecioVenta);
            this.grpInformacionPrecioVenta.Location = new System.Drawing.Point(490, 57);
            this.grpInformacionPrecioVenta.Margin = new System.Windows.Forms.Padding(2);
            this.grpInformacionPrecioVenta.Name = "grpInformacionPrecioVenta";
            this.grpInformacionPrecioVenta.Padding = new System.Windows.Forms.Padding(2);
            this.grpInformacionPrecioVenta.Size = new System.Drawing.Size(299, 150);
            this.grpInformacionPrecioVenta.TabIndex = 8;
            this.grpInformacionPrecioVenta.TabStop = false;
            this.grpInformacionPrecioVenta.Text = "Información de Precio y Venta";
            // 
            // radNo
            // 
            this.radNo.AutoSize = true;
            this.radNo.Location = new System.Drawing.Point(210, 98);
            this.radNo.Name = "radNo";
            this.radNo.Size = new System.Drawing.Size(39, 17);
            this.radNo.TabIndex = 12;
            this.radNo.TabStop = true;
            this.radNo.Text = "No";
            this.radNo.UseVisualStyleBackColor = true;
            // 
            // txtPrecioVenta
            // 
            this.txtPrecioVenta.Location = new System.Drawing.Point(131, 62);
            this.txtPrecioVenta.Name = "txtPrecioVenta";
            this.txtPrecioVenta.Size = new System.Drawing.Size(60, 20);
            this.txtPrecioVenta.TabIndex = 5;
            // 
            // radSi
            // 
            this.radSi.AutoSize = true;
            this.radSi.Location = new System.Drawing.Point(157, 98);
            this.radSi.Name = "radSi";
            this.radSi.Size = new System.Drawing.Size(34, 17);
            this.radSi.TabIndex = 11;
            this.radSi.TabStop = true;
            this.radSi.Text = "Si";
            this.radSi.UseVisualStyleBackColor = true;
            this.radSi.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // txtPrecioCompra
            // 
            this.txtPrecioCompra.Location = new System.Drawing.Point(131, 29);
            this.txtPrecioCompra.Name = "txtPrecioCompra";
            this.txtPrecioCompra.Size = new System.Drawing.Size(60, 20);
            this.txtPrecioCompra.TabIndex = 4;
            // 
            // lblDescuento
            // 
            this.lblDescuento.AutoSize = true;
            this.lblDescuento.Location = new System.Drawing.Point(32, 100);
            this.lblDescuento.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDescuento.Name = "lblDescuento";
            this.lblDescuento.Size = new System.Drawing.Size(107, 13);
            this.lblDescuento.TabIndex = 3;
            this.lblDescuento.Text = "Descuento aplicable:";
            this.lblDescuento.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPrecioCompra
            // 
            this.lblPrecioCompra.AutoSize = true;
            this.lblPrecioCompra.Location = new System.Drawing.Point(32, 32);
            this.lblPrecioCompra.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrecioCompra.Name = "lblPrecioCompra";
            this.lblPrecioCompra.Size = new System.Drawing.Size(94, 13);
            this.lblPrecioCompra.TabIndex = 1;
            this.lblPrecioCompra.Text = "Precio de Compra:";
            // 
            // lblPrecioVenta
            // 
            this.lblPrecioVenta.AutoSize = true;
            this.lblPrecioVenta.Location = new System.Drawing.Point(32, 65);
            this.lblPrecioVenta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrecioVenta.Name = "lblPrecioVenta";
            this.lblPrecioVenta.Size = new System.Drawing.Size(86, 13);
            this.lblPrecioVenta.TabIndex = 2;
            this.lblPrecioVenta.Text = "Precio de Venta:";
            // 
            // grpInformacionProveedor
            // 
            this.grpInformacionProveedor.Controls.Add(this.mtxtContacto);
            this.grpInformacionProveedor.Controls.Add(this.txtCodigoProveedor);
            this.grpInformacionProveedor.Controls.Add(this.txtNombreProveedor);
            this.grpInformacionProveedor.Controls.Add(this.lblContactoProveedor);
            this.grpInformacionProveedor.Controls.Add(this.lblNombreProveedor);
            this.grpInformacionProveedor.Controls.Add(this.lblCodigoProveedor);
            this.grpInformacionProveedor.Location = new System.Drawing.Point(490, 223);
            this.grpInformacionProveedor.Margin = new System.Windows.Forms.Padding(2);
            this.grpInformacionProveedor.Name = "grpInformacionProveedor";
            this.grpInformacionProveedor.Padding = new System.Windows.Forms.Padding(2);
            this.grpInformacionProveedor.Size = new System.Drawing.Size(299, 150);
            this.grpInformacionProveedor.TabIndex = 9;
            this.grpInformacionProveedor.TabStop = false;
            this.grpInformacionProveedor.Text = "Información del Proveedor";
            // 
            // mtxtContacto
            // 
            this.mtxtContacto.Location = new System.Drawing.Point(91, 97);
            this.mtxtContacto.Mask = "0000-0000";
            this.mtxtContacto.Name = "mtxtContacto";
            this.mtxtContacto.Size = new System.Drawing.Size(88, 20);
            this.mtxtContacto.TabIndex = 8;
            // 
            // txtCodigoProveedor
            // 
            this.txtCodigoProveedor.Location = new System.Drawing.Point(91, 62);
            this.txtCodigoProveedor.Name = "txtCodigoProveedor";
            this.txtCodigoProveedor.Size = new System.Drawing.Size(75, 20);
            this.txtCodigoProveedor.TabIndex = 7;
            // 
            // txtNombreProveedor
            // 
            this.txtNombreProveedor.Location = new System.Drawing.Point(91, 29);
            this.txtNombreProveedor.Name = "txtNombreProveedor";
            this.txtNombreProveedor.Size = new System.Drawing.Size(141, 20);
            this.txtNombreProveedor.TabIndex = 4;
            this.txtNombreProveedor.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // lblContactoProveedor
            // 
            this.lblContactoProveedor.AutoSize = true;
            this.lblContactoProveedor.Location = new System.Drawing.Point(32, 100);
            this.lblContactoProveedor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblContactoProveedor.Name = "lblContactoProveedor";
            this.lblContactoProveedor.Size = new System.Drawing.Size(53, 13);
            this.lblContactoProveedor.TabIndex = 3;
            this.lblContactoProveedor.Text = "Contacto:";
            this.lblContactoProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblNombreProveedor
            // 
            this.lblNombreProveedor.AutoSize = true;
            this.lblNombreProveedor.Location = new System.Drawing.Point(32, 32);
            this.lblNombreProveedor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNombreProveedor.Name = "lblNombreProveedor";
            this.lblNombreProveedor.Size = new System.Drawing.Size(47, 13);
            this.lblNombreProveedor.TabIndex = 1;
            this.lblNombreProveedor.Text = "Nombre:";
            // 
            // lblCodigoProveedor
            // 
            this.lblCodigoProveedor.AutoSize = true;
            this.lblCodigoProveedor.Location = new System.Drawing.Point(32, 65);
            this.lblCodigoProveedor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCodigoProveedor.Name = "lblCodigoProveedor";
            this.lblCodigoProveedor.Size = new System.Drawing.Size(43, 13);
            this.lblCodigoProveedor.TabIndex = 2;
            this.lblCodigoProveedor.Text = "Código:";
            // 
            // grpFechasImportantes
            // 
            this.grpFechasImportantes.Controls.Add(this.mtxtFechaCaducidad);
            this.grpFechasImportantes.Controls.Add(this.mtxtFechaEntrada);
            this.grpFechasImportantes.Controls.Add(this.lblFechaEntrada);
            this.grpFechasImportantes.Controls.Add(this.lblFechaCaducidad);
            this.grpFechasImportantes.Location = new System.Drawing.Point(322, 303);
            this.grpFechasImportantes.Margin = new System.Windows.Forms.Padding(2);
            this.grpFechasImportantes.Name = "grpFechasImportantes";
            this.grpFechasImportantes.Padding = new System.Windows.Forms.Padding(2);
            this.grpFechasImportantes.Size = new System.Drawing.Size(151, 150);
            this.grpFechasImportantes.TabIndex = 10;
            this.grpFechasImportantes.TabStop = false;
            this.grpFechasImportantes.Text = "Fechas Importantes";
            // 
            // mtxtFechaCaducidad
            // 
            this.mtxtFechaCaducidad.Location = new System.Drawing.Point(25, 106);
            this.mtxtFechaCaducidad.Mask = "00/00/0000";
            this.mtxtFechaCaducidad.Name = "mtxtFechaCaducidad";
            this.mtxtFechaCaducidad.Size = new System.Drawing.Size(100, 20);
            this.mtxtFechaCaducidad.TabIndex = 4;
            this.mtxtFechaCaducidad.ValidatingType = typeof(System.DateTime);
            // 
            // mtxtFechaEntrada
            // 
            this.mtxtFechaEntrada.Location = new System.Drawing.Point(25, 44);
            this.mtxtFechaEntrada.Mask = "00/00/0000";
            this.mtxtFechaEntrada.Name = "mtxtFechaEntrada";
            this.mtxtFechaEntrada.Size = new System.Drawing.Size(100, 20);
            this.mtxtFechaEntrada.TabIndex = 3;
            this.mtxtFechaEntrada.ValidatingType = typeof(System.DateTime);
            // 
            // lblFechaEntrada
            // 
            this.lblFechaEntrada.AutoSize = true;
            this.lblFechaEntrada.Location = new System.Drawing.Point(22, 28);
            this.lblFechaEntrada.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFechaEntrada.Name = "lblFechaEntrada";
            this.lblFechaEntrada.Size = new System.Drawing.Size(95, 13);
            this.lblFechaEntrada.TabIndex = 1;
            this.lblFechaEntrada.Text = "Fecha de Entrada:";
            // 
            // lblFechaCaducidad
            // 
            this.lblFechaCaducidad.AutoSize = true;
            this.lblFechaCaducidad.Location = new System.Drawing.Point(22, 90);
            this.lblFechaCaducidad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFechaCaducidad.Name = "lblFechaCaducidad";
            this.lblFechaCaducidad.Size = new System.Drawing.Size(109, 13);
            this.lblFechaCaducidad.TabIndex = 2;
            this.lblFechaCaducidad.Text = "Fecha de Caducidad:";
            // 
            // PharmTrack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(798, 466);
            this.Controls.Add(this.grpFechasImportantes);
            this.Controls.Add(this.grpInformacionProveedor);
            this.Controls.Add(this.grpInformacionPrecioVenta);
            this.Controls.Add(this.grpCantidadPresentacion);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.grpInformacionMedicamento);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PharmTrack";
            this.Opacity = 0.4D;
            this.Text = "PharmTrack";
            this.grpInformacionMedicamento.ResumeLayout(false);
            this.grpInformacionMedicamento.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpCantidadPresentacion.ResumeLayout(false);
            this.grpCantidadPresentacion.PerformLayout();
            this.grpInformacionPrecioVenta.ResumeLayout(false);
            this.grpInformacionPrecioVenta.PerformLayout();
            this.grpInformacionProveedor.ResumeLayout(false);
            this.grpInformacionProveedor.PerformLayout();
            this.grpFechasImportantes.ResumeLayout(false);
            this.grpFechasImportantes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.GroupBox grpInformacionMedicamento;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox grpCantidadPresentacion;
        private System.Windows.Forms.Label lblCantidadEmpaque;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Label lblMedida;
        private System.Windows.Forms.GroupBox grpInformacionPrecioVenta;
        private System.Windows.Forms.Label lblDescuento;
        private System.Windows.Forms.Label lblPrecioCompra;
        private System.Windows.Forms.Label lblPrecioVenta;
        private System.Windows.Forms.GroupBox grpInformacionProveedor;
        private System.Windows.Forms.Label lblContactoProveedor;
        private System.Windows.Forms.Label lblNombreProveedor;
        private System.Windows.Forms.Label lblCodigoProveedor;
        private System.Windows.Forms.GroupBox grpFechasImportantes;
        private System.Windows.Forms.Label lblFechaEntrada;
        private System.Windows.Forms.Label lblFechaCaducidad;
        private System.Windows.Forms.TextBox txtCodigoMedicamento;
        private System.Windows.Forms.TextBox txtTipoMedicamento;
        private System.Windows.Forms.TextBox txtDescripcionMedicamento;
        private System.Windows.Forms.TextBox txtNombreMedicamento;
        private System.Windows.Forms.TextBox txtUnidadMedida;
        private System.Windows.Forms.TextBox txtCantidadStock;
        private System.Windows.Forms.TextBox txtCantidadEmpaque;
        private System.Windows.Forms.TextBox txtPrecioCompra;
        private System.Windows.Forms.MaskedTextBox mtxtFechaCaducidad;
        private System.Windows.Forms.MaskedTextBox mtxtFechaEntrada;
        private System.Windows.Forms.TextBox txtPrecioVenta;
        private System.Windows.Forms.TextBox txtNombreProveedor;
        private System.Windows.Forms.MaskedTextBox mtxtContacto;
        private System.Windows.Forms.TextBox txtCodigoProveedor;
        private System.Windows.Forms.RadioButton radSi;
        private System.Windows.Forms.RadioButton radNo;
    }
}

