﻿namespace PedidoDeProductoFarmTrack
{
    partial class PedidoProducto
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombreCompleto = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblDireccionDeEntrega = new System.Windows.Forms.Label();
            this.lblCorreoElectronico = new System.Windows.Forms.Label();
            this.grpDatosDelCliente = new System.Windows.Forms.GroupBox();
            this.mtxtTelefono = new System.Windows.Forms.MaskedTextBox();
            this.txtNombreCompleto = new System.Windows.Forms.TextBox();
            this.txtCorreoElectronico = new System.Windows.Forms.TextBox();
            this.txtDireccionDeEntrega = new System.Windows.Forms.TextBox();
            this.grpDetallesDelProducto = new System.Windows.Forms.GroupBox();
            this.dtpFechaDePedido = new System.Windows.Forms.DateTimePicker();
            this.cmbPresentacion = new System.Windows.Forms.ComboBox();
            this.txtProducto = new System.Windows.Forms.TextBox();
            this.nudCantidad = new System.Windows.Forms.NumericUpDown();
            this.lblFechaDePedido = new System.Windows.Forms.Label();
            this.lblPresentacion = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.lblProducto = new System.Windows.Forms.Label();
            this.grpMetodoDePago = new System.Windows.Forms.GroupBox();
            this.radTarjeta = new System.Windows.Forms.RadioButton();
            this.radTransferencia = new System.Windows.Forms.RadioButton();
            this.radEfectivo = new System.Windows.Forms.RadioButton();
            this.lblDatosDePago = new System.Windows.Forms.Label();
            this.lblOpcionesDePago = new System.Windows.Forms.Label();
            this.btnRealizarPedido = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.grpDatosDelCliente.SuspendLayout();
            this.grpDetallesDelProducto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCantidad)).BeginInit();
            this.grpMetodoDePago.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNombreCompleto
            // 
            this.lblNombreCompleto.AutoSize = true;
            this.lblNombreCompleto.Location = new System.Drawing.Point(6, 35);
            this.lblNombreCompleto.Name = "lblNombreCompleto";
            this.lblNombreCompleto.Size = new System.Drawing.Size(159, 22);
            this.lblNombreCompleto.TabIndex = 0;
            this.lblNombreCompleto.Text = "Nombre Completo:";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(6, 75);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(86, 22);
            this.lblTelefono.TabIndex = 1;
            this.lblTelefono.Text = "Teléfono:";
            // 
            // lblDireccionDeEntrega
            // 
            this.lblDireccionDeEntrega.AutoSize = true;
            this.lblDireccionDeEntrega.Location = new System.Drawing.Point(6, 117);
            this.lblDireccionDeEntrega.Name = "lblDireccionDeEntrega";
            this.lblDireccionDeEntrega.Size = new System.Drawing.Size(183, 22);
            this.lblDireccionDeEntrega.TabIndex = 2;
            this.lblDireccionDeEntrega.Text = "Dirección de Entrega:";
            // 
            // lblCorreoElectronico
            // 
            this.lblCorreoElectronico.AutoSize = true;
            this.lblCorreoElectronico.Location = new System.Drawing.Point(6, 226);
            this.lblCorreoElectronico.Name = "lblCorreoElectronico";
            this.lblCorreoElectronico.Size = new System.Drawing.Size(164, 22);
            this.lblCorreoElectronico.TabIndex = 3;
            this.lblCorreoElectronico.Text = "Correo Eléctronico:";
            // 
            // grpDatosDelCliente
            // 
            this.grpDatosDelCliente.Controls.Add(this.mtxtTelefono);
            this.grpDatosDelCliente.Controls.Add(this.txtNombreCompleto);
            this.grpDatosDelCliente.Controls.Add(this.txtCorreoElectronico);
            this.grpDatosDelCliente.Controls.Add(this.txtDireccionDeEntrega);
            this.grpDatosDelCliente.Controls.Add(this.lblNombreCompleto);
            this.grpDatosDelCliente.Controls.Add(this.lblCorreoElectronico);
            this.grpDatosDelCliente.Controls.Add(this.lblTelefono);
            this.grpDatosDelCliente.Controls.Add(this.lblDireccionDeEntrega);
            this.grpDatosDelCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDatosDelCliente.ForeColor = System.Drawing.SystemColors.MenuText;
            this.grpDatosDelCliente.Location = new System.Drawing.Point(12, 12);
            this.grpDatosDelCliente.Name = "grpDatosDelCliente";
            this.grpDatosDelCliente.Size = new System.Drawing.Size(592, 270);
            this.grpDatosDelCliente.TabIndex = 4;
            this.grpDatosDelCliente.TabStop = false;
            this.grpDatosDelCliente.Text = "Datos del Cliente";
            // 
            // mtxtTelefono
            // 
            this.mtxtTelefono.Location = new System.Drawing.Point(195, 72);
            this.mtxtTelefono.Mask = "+(000) 0000-0000";
            this.mtxtTelefono.Name = "mtxtTelefono";
            this.mtxtTelefono.Size = new System.Drawing.Size(391, 28);
            this.mtxtTelefono.TabIndex = 7;
            this.mtxtTelefono.Click += new System.EventHandler(this.PosicionDeInicio_Click);
            this.mtxtTelefono.Enter += new System.EventHandler(this.PosicionDeInicio_Enter);
            // 
            // txtNombreCompleto
            // 
            this.txtNombreCompleto.Location = new System.Drawing.Point(195, 32);
            this.txtNombreCompleto.Name = "txtNombreCompleto";
            this.txtNombreCompleto.Size = new System.Drawing.Size(391, 28);
            this.txtNombreCompleto.TabIndex = 6;
            this.txtNombreCompleto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ValidacionSoloLetras);
            // 
            // txtCorreoElectronico
            // 
            this.txtCorreoElectronico.Location = new System.Drawing.Point(195, 223);
            this.txtCorreoElectronico.Name = "txtCorreoElectronico";
            this.txtCorreoElectronico.Size = new System.Drawing.Size(391, 28);
            this.txtCorreoElectronico.TabIndex = 5;
            // 
            // txtDireccionDeEntrega
            // 
            this.txtDireccionDeEntrega.Location = new System.Drawing.Point(195, 114);
            this.txtDireccionDeEntrega.Multiline = true;
            this.txtDireccionDeEntrega.Name = "txtDireccionDeEntrega";
            this.txtDireccionDeEntrega.Size = new System.Drawing.Size(391, 103);
            this.txtDireccionDeEntrega.TabIndex = 4;
            // 
            // grpDetallesDelProducto
            // 
            this.grpDetallesDelProducto.Controls.Add(this.dtpFechaDePedido);
            this.grpDetallesDelProducto.Controls.Add(this.cmbPresentacion);
            this.grpDetallesDelProducto.Controls.Add(this.txtProducto);
            this.grpDetallesDelProducto.Controls.Add(this.nudCantidad);
            this.grpDetallesDelProducto.Controls.Add(this.lblFechaDePedido);
            this.grpDetallesDelProducto.Controls.Add(this.lblPresentacion);
            this.grpDetallesDelProducto.Controls.Add(this.lblCantidad);
            this.grpDetallesDelProducto.Controls.Add(this.lblProducto);
            this.grpDetallesDelProducto.Location = new System.Drawing.Point(610, 12);
            this.grpDetallesDelProducto.Name = "grpDetallesDelProducto";
            this.grpDetallesDelProducto.Size = new System.Drawing.Size(531, 270);
            this.grpDetallesDelProducto.TabIndex = 5;
            this.grpDetallesDelProducto.TabStop = false;
            this.grpDetallesDelProducto.Text = "Detalles del Producto";
            // 
            // dtpFechaDePedido
            // 
            this.dtpFechaDePedido.Location = new System.Drawing.Point(210, 167);
            this.dtpFechaDePedido.Name = "dtpFechaDePedido";
            this.dtpFechaDePedido.Size = new System.Drawing.Size(288, 28);
            this.dtpFechaDePedido.TabIndex = 8;
            // 
            // cmbPresentacion
            // 
            this.cmbPresentacion.FormattingEnabled = true;
            this.cmbPresentacion.Items.AddRange(new object[] {
            "Tabletas",
            "Jarabe",
            "Ampolla"});
            this.cmbPresentacion.Location = new System.Drawing.Point(210, 117);
            this.cmbPresentacion.Name = "cmbPresentacion";
            this.cmbPresentacion.Size = new System.Drawing.Size(288, 30);
            this.cmbPresentacion.TabIndex = 7;
            // 
            // txtProducto
            // 
            this.txtProducto.Location = new System.Drawing.Point(210, 32);
            this.txtProducto.Name = "txtProducto";
            this.txtProducto.Size = new System.Drawing.Size(288, 28);
            this.txtProducto.TabIndex = 6;
            // 
            // nudCantidad
            // 
            this.nudCantidad.Location = new System.Drawing.Point(210, 72);
            this.nudCantidad.Name = "nudCantidad";
            this.nudCantidad.Size = new System.Drawing.Size(120, 28);
            this.nudCantidad.TabIndex = 5;
            // 
            // lblFechaDePedido
            // 
            this.lblFechaDePedido.AutoSize = true;
            this.lblFechaDePedido.Location = new System.Drawing.Point(6, 167);
            this.lblFechaDePedido.Name = "lblFechaDePedido";
            this.lblFechaDePedido.Size = new System.Drawing.Size(151, 22);
            this.lblFechaDePedido.TabIndex = 3;
            this.lblFechaDePedido.Text = "Fecha de Pedido:";
            // 
            // lblPresentacion
            // 
            this.lblPresentacion.AutoSize = true;
            this.lblPresentacion.Location = new System.Drawing.Point(6, 117);
            this.lblPresentacion.Name = "lblPresentacion";
            this.lblPresentacion.Size = new System.Drawing.Size(120, 22);
            this.lblPresentacion.TabIndex = 2;
            this.lblPresentacion.Text = "Presentación:";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Location = new System.Drawing.Point(6, 75);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(87, 22);
            this.lblCantidad.TabIndex = 1;
            this.lblCantidad.Text = "Cantidad:";
            // 
            // lblProducto
            // 
            this.lblProducto.AutoSize = true;
            this.lblProducto.Location = new System.Drawing.Point(6, 35);
            this.lblProducto.Name = "lblProducto";
            this.lblProducto.Size = new System.Drawing.Size(198, 22);
            this.lblProducto.TabIndex = 0;
            this.lblProducto.Text = "Producto/Medicamento:";
            // 
            // grpMetodoDePago
            // 
            this.grpMetodoDePago.Controls.Add(this.radTarjeta);
            this.grpMetodoDePago.Controls.Add(this.radTransferencia);
            this.grpMetodoDePago.Controls.Add(this.radEfectivo);
            this.grpMetodoDePago.Controls.Add(this.lblDatosDePago);
            this.grpMetodoDePago.Controls.Add(this.lblOpcionesDePago);
            this.grpMetodoDePago.Location = new System.Drawing.Point(3, 310);
            this.grpMetodoDePago.Name = "grpMetodoDePago";
            this.grpMetodoDePago.Size = new System.Drawing.Size(700, 127);
            this.grpMetodoDePago.TabIndex = 6;
            this.grpMetodoDePago.TabStop = false;
            this.grpMetodoDePago.Text = "Método de Pago";
            // 
            // radTarjeta
            // 
            this.radTarjeta.AutoSize = true;
            this.radTarjeta.Location = new System.Drawing.Point(458, 39);
            this.radTarjeta.Name = "radTarjeta";
            this.radTarjeta.Size = new System.Drawing.Size(233, 26);
            this.radTarjeta.TabIndex = 4;
            this.radTarjeta.TabStop = true;
            this.radTarjeta.Text = "Tarjeta de Crédito/Débito";
            this.radTarjeta.UseVisualStyleBackColor = true;
            // 
            // radTransferencia
            // 
            this.radTransferencia.AutoSize = true;
            this.radTransferencia.Location = new System.Drawing.Point(305, 39);
            this.radTransferencia.Name = "radTransferencia";
            this.radTransferencia.Size = new System.Drawing.Size(147, 26);
            this.radTransferencia.TabIndex = 3;
            this.radTransferencia.TabStop = true;
            this.radTransferencia.Text = "Transferencia ";
            this.radTransferencia.UseVisualStyleBackColor = true;
            // 
            // radEfectivo
            // 
            this.radEfectivo.AutoSize = true;
            this.radEfectivo.Location = new System.Drawing.Point(204, 39);
            this.radEfectivo.Name = "radEfectivo";
            this.radEfectivo.Size = new System.Drawing.Size(95, 26);
            this.radEfectivo.TabIndex = 2;
            this.radEfectivo.TabStop = true;
            this.radEfectivo.Text = "Efectivo";
            this.radEfectivo.UseVisualStyleBackColor = true;
            // 
            // lblDatosDePago
            // 
            this.lblDatosDePago.AutoSize = true;
            this.lblDatosDePago.Location = new System.Drawing.Point(15, 78);
            this.lblDatosDePago.Name = "lblDatosDePago";
            this.lblDatosDePago.Size = new System.Drawing.Size(134, 22);
            this.lblDatosDePago.TabIndex = 1;
            this.lblDatosDePago.Text = "Datos de Pago:";
            // 
            // lblOpcionesDePago
            // 
            this.lblOpcionesDePago.AutoSize = true;
            this.lblOpcionesDePago.Location = new System.Drawing.Point(15, 39);
            this.lblOpcionesDePago.Name = "lblOpcionesDePago";
            this.lblOpcionesDePago.Size = new System.Drawing.Size(163, 22);
            this.lblOpcionesDePago.TabIndex = 0;
            this.lblOpcionesDePago.Text = "Opciones de Pago:";
            // 
            // btnRealizarPedido
            // 
            this.btnRealizarPedido.Location = new System.Drawing.Point(728, 398);
            this.btnRealizarPedido.Name = "btnRealizarPedido";
            this.btnRealizarPedido.Size = new System.Drawing.Size(170, 39);
            this.btnRealizarPedido.TabIndex = 7;
            this.btnRealizarPedido.Text = "Realizar Pedido";
            this.btnRealizarPedido.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(938, 398);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(170, 39);
            this.btnCancelar.TabIndex = 8;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // PedidoProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 663);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnRealizarPedido);
            this.Controls.Add(this.grpMetodoDePago);
            this.Controls.Add(this.grpDetallesDelProducto);
            this.Controls.Add(this.grpDatosDelCliente);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PedidoProducto";
            this.Text = "Pedido de Producto";
            this.grpDatosDelCliente.ResumeLayout(false);
            this.grpDatosDelCliente.PerformLayout();
            this.grpDetallesDelProducto.ResumeLayout(false);
            this.grpDetallesDelProducto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCantidad)).EndInit();
            this.grpMetodoDePago.ResumeLayout(false);
            this.grpMetodoDePago.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblNombreCompleto;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblDireccionDeEntrega;
        private System.Windows.Forms.Label lblCorreoElectronico;
        private System.Windows.Forms.GroupBox grpDatosDelCliente;
        private System.Windows.Forms.TextBox txtDireccionDeEntrega;
        private System.Windows.Forms.TextBox txtNombreCompleto;
        private System.Windows.Forms.TextBox txtCorreoElectronico;
        private System.Windows.Forms.GroupBox grpDetallesDelProducto;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.Label lblProducto;
        private System.Windows.Forms.Label lblFechaDePedido;
        private System.Windows.Forms.Label lblPresentacion;
        private System.Windows.Forms.NumericUpDown nudCantidad;
        private System.Windows.Forms.ComboBox cmbPresentacion;
        private System.Windows.Forms.TextBox txtProducto;
        private System.Windows.Forms.DateTimePicker dtpFechaDePedido;
        private System.Windows.Forms.GroupBox grpMetodoDePago;
        private System.Windows.Forms.Label lblDatosDePago;
        private System.Windows.Forms.Label lblOpcionesDePago;
        private System.Windows.Forms.RadioButton radTransferencia;
        private System.Windows.Forms.RadioButton radEfectivo;
        private System.Windows.Forms.RadioButton radTarjeta;
        private System.Windows.Forms.Button btnRealizarPedido;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.MaskedTextBox mtxtTelefono;
    }
}

