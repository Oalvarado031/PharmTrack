﻿using InterfazLoginPharmaTrack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PedidoDeProductoFarmTrack
{
    public partial class PedidoProducto : Form
    {
        public PedidoProducto()
        {
            InitializeComponent();
        }


        private void btncancelar_Click(object sender, EventArgs e)
        {
            Opciones opc = new Opciones();
            opc.Show();
            Close();
        }

        private void ValidacionSoloLetras(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != (char)Keys.Space)
            {
                e.Handled = true;
            }
        }

        private void PosicionDeInicio_Click(object sender, EventArgs e)
        {
            //Mueve el cursor al inicio del MaskedTextBox
            (sender as MaskedTextBox).SelectionStart = 0;
        }

        private void PosicionDeInicio_Enter(object sender, EventArgs e)
        {
            /*Igual mueve el cursor al inicio, pero cuando recibe el foco a través de otros medios,
            por ejemplo al presionat TAB*/
            (sender as MaskedTextBox).SelectionStart = 0;
        }
    }
}
