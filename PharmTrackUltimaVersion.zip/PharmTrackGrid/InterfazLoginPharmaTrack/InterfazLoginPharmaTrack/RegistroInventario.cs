﻿using InterfazLoginPharmaTrack;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoPharmTrack
{
    public partial class RegistroInventario : Form
    {
        private List<InventarioProductos> inventarioProductos; //Declarando la lista
        private InventarioProductos inventarioSel = new InventarioProductos(); //Declarando la variable de estructura

        public RegistroInventario()
        {
            InitializeComponent();
            inventarioProductos = new List<InventarioProductos>();
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            InventarioProductos inventario = new InventarioProductos();

            // Validar Código de Medicamento
            if (!int.TryParse(txtCodigoMedicamento.Text, out int codigoMedicamento))
            {
                MessageBox.Show("Ingrese un código de medicamento válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.CodigoMedicamento = codigoMedicamento;

            // Validar Nombre de Medicamento
            inventario.NombreMedicamento = txtNombreMedicamento.Text;
            if (string.IsNullOrWhiteSpace(inventario.NombreMedicamento))
            {
                MessageBox.Show("El nombre del medicamento no puede estar vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar Descripción
            inventario.DescripcionMedicamento = txtDescripcionMedicamento.Text;

            // Validar Tipo de Medicamento
            inventario.TipoMedicamento = txtTipoMedicamento.Text;

            // Validar Stock
            if (!int.TryParse(txtCantidadStock.Text, out int stockMedicamento))
            {
                MessageBox.Show("Ingrese una cantidad de stock válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.StockMedicamento = stockMedicamento;

            // Validar Unidad de Medida
            inventario.UnidadMedida = txtUnidadMedida.Text;

            // Validar Cantidad de Empaque
            if (!int.TryParse(txtCantidadEmpaque.Text, out int cantidadEmpaque))
            {
                MessageBox.Show("Ingrese una cantidad de empaque válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.CantidadEmpaque = cantidadEmpaque;

            // Validar Fecha de Entrada
            if (!DateTime.TryParse(mtxtFechaEntrada.Text, out DateTime fechaEntrada))
            {
                MessageBox.Show("Ingrese una fecha de entrada válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.FechaDeEntrada = fechaEntrada;

            // Validar Fecha de Caducidad
            if (!DateTime.TryParse(mtxtFechaCaducidad.Text, out DateTime fechaSalida))
            {
                MessageBox.Show("Ingrese una fecha de caducidad válida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.FechaDeSalida = fechaSalida;

            // Validar Precio de Compra
            if (!float.TryParse(txtPrecioCompra.Text, out float precioCompra))
            {
                MessageBox.Show("Ingrese un precio de compra válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.PrecioDeCompra = precioCompra;

            // Validar Precio de Venta
            if (!float.TryParse(txtPrecioVenta.Text, out float precioVenta))
            {
                MessageBox.Show("Ingrese un precio de venta válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.PrecioDeVenta = precioVenta;

            // Validar Nombre del Proveedor
            inventario.NombreProveedor = txtNombreProveedor.Text;

            // Validar Código del Proveedor
            if (!int.TryParse(txtCodigoProveedor.Text, out int codigoProveedor))
            {
                MessageBox.Show("Ingrese un código de proveedor válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.CodigoProveedor = codigoProveedor;

            // Validar Contacto del Proveedor
            if (!int.TryParse(txtContacto.Text, out int contactoProveedor))
            {
                MessageBox.Show("Ingrese un número de contacto válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            inventario.ContactoProveedor = contactoProveedor;

            // Agregar o actualizar el inventario
            int index = inventarioProductos.FindIndex(item => item.CodigoMedicamento == inventario.CodigoMedicamento);
            if (index != -1)
            {
                inventarioProductos[index] = inventario;
            }
            else
            {
                inventarioProductos.Add(inventario);
            }

            // Mostrar datos y limpiar campos
            MostrarDatos();
            LimpiarCodigo();
        }


        private void MostrarDatos()
        {
            dataGridViewInventario.DataSource = null;
            dataGridViewInventario.DataSource = inventarioProductos;
        }

        private void LimpiarCodigo()
        {
            txtCodigoMedicamento.Clear();
            txtNombreMedicamento.Clear();
            txtDescripcionMedicamento.Clear();
            txtTipoMedicamento.Clear();
            txtCantidadStock.Clear();
            txtUnidadMedida.Clear();
            txtCantidadEmpaque.Clear();
            mtxtFechaEntrada.Clear();
            mtxtFechaCaducidad.Clear();
            txtPrecioCompra.Clear();
            txtPrecioVenta.Clear();
            txtNombreProveedor.Clear();
            txtCodigoProveedor.Clear();
            txtContacto.Clear();
            radNo.Checked = false;
            radSi.Checked = false;
            txtCodigoMedicamento.Focus();
        }

        private void dataGridViewInventario_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewInventario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtCodigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void grpInformacionProveedor_Enter(object sender, EventArgs e)
        {

        }

        private void PedidoProducto_Load(object sender, EventArgs e)
        {

        }

        private void dataGridViewInventario_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow currentRow = dataGridViewInventario.CurrentRow;
            if (currentRow != null)
            {
                inventarioSel.CodigoMedicamento = int.Parse(currentRow.Cells[0].Value.ToString());
                inventarioSel.NombreMedicamento = currentRow.Cells[1].Value.ToString();
                inventarioSel.DescripcionMedicamento = currentRow.Cells[2].Value.ToString();
                inventarioSel.TipoMedicamento = currentRow.Cells[3].Value.ToString();
                inventarioSel.StockMedicamento = int.Parse(currentRow.Cells[4].Value.ToString());
                inventarioSel.UnidadMedida = currentRow.Cells[5].Value.ToString();
                inventarioSel.CantidadEmpaque = int.Parse(currentRow.Cells[6].Value.ToString());

                // Control de fecha para FechaDeEntrada
                if (DateTime.TryParseExact(currentRow.Cells[7].Value.ToString(), "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out DateTime fechaEntrada))
                {
                    inventarioSel.FechaDeEntrada = fechaEntrada;
                    mtxtFechaEntrada.Text = fechaEntrada.ToString("yyyy-MM-dd");
                }
                else
                {
                    MessageBox.Show("Formato inválido para Fecha de Entrada. Use el formato 'yyyy-MM-dd'.", "Error de Fecha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Control de fecha para FechaDeSalida
                if (DateTime.TryParseExact(currentRow.Cells[8].Value.ToString(), "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out DateTime fechaSalida))
                {
                    inventarioSel.FechaDeSalida = fechaSalida;
                    mtxtFechaCaducidad.Text = fechaSalida.ToString("yyyy-MM-dd");
                }
                else
                {
                    MessageBox.Show("Formato inválido para Fecha de Salida. Use el formato 'yyyy-MM-dd'.", "Error de Fecha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                inventarioSel.PrecioDeCompra = float.Parse(currentRow.Cells[9].Value.ToString());
                inventarioSel.PrecioDeVenta = float.Parse(currentRow.Cells[10].Value.ToString());
                inventarioSel.NombreProveedor = currentRow.Cells[11].Value.ToString();
                inventarioSel.CodigoProveedor = int.Parse(currentRow.Cells[12].Value.ToString());
                inventarioSel.ContactoProveedor = int.Parse(currentRow.Cells[13].Value.ToString());

                // Llenar los campos de texto con los valores seleccionados
                txtCodigoMedicamento.Text = inventarioSel.CodigoMedicamento.ToString();
                txtNombreMedicamento.Text = inventarioSel.NombreMedicamento;
                txtDescripcionMedicamento.Text = inventarioSel.DescripcionMedicamento;
                txtTipoMedicamento.Text = inventarioSel.TipoMedicamento;
                txtCantidadStock.Text = inventarioSel.StockMedicamento.ToString();
                txtUnidadMedida.Text = inventarioSel.UnidadMedida;
                txtCantidadEmpaque.Text = inventarioSel.CantidadEmpaque.ToString();
                txtPrecioCompra.Text = inventarioSel.PrecioDeCompra.ToString("F2");
                txtPrecioVenta.Text = inventarioSel.PrecioDeVenta.ToString("F2");
                txtNombreProveedor.Text = inventarioSel.NombreProveedor;
                txtCodigoProveedor.Text = inventarioSel.CodigoProveedor.ToString();
                txtContacto.Text = inventarioSel.ContactoProveedor.ToString();
            }
        }
    }
}